SFA3 UPPER C11 - 240p / 384 x 224 Patcher

1. Extract this ZIP and open SFA3_UPPER_Patcher_C11_240p_384x224.exe.
2. Select sfz3ugd.zip and gdl-0002.chd together, or select a supported stock
   DAT/BIN. The ZIP and CHD can also be selected separately.
3. Select your PSP Alpha 3 MAX / Zero 3 Double Upper file, in any region or
   format, using the PSP field. You can drop it directly onto that field.
4. Choose an output folder and click Create BIN.

Output: SFA3U_C11_240p_384x224_Fixes.bin

This creates the latest released 240p build with the approved fixes. The
Operator Menu contains VMU MODE and CROUCH CANCEL. Bilinear is removed.
Title prompts are raised ten native pixels (two below the previous release) clear of the copyright.
Coin credit counts fit between the prompt and copyright in the native font.

Windows x64. Fully offline; no Python or separate conversion tools needed.
Original input files are preserved. Existing output files are not overwritten.

See VALIDATION.txt for test scope and the output checksum.
