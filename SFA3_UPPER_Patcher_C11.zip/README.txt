SFA3 UPPER C11 - Offline Netboot Patcher

1. Select stock sfz3ugd.zip and gdl-0002.chd. A supported stock DAT/BIN can also be used.
2. Select your PSP Street Fighter Alpha 3 MAX game file. Any region/edition is accepted.
3. Choose an output folder and create the BIN.


