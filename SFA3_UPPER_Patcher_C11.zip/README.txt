SFA3 UPPER C11 - Offline Netboot Patcher
Patcher revision 1.0.1.2 - PSP file selection correction

1. Select stock sfz3ugd.zip and gdl-0002.chd. A supported stock DAT/BIN can also be used.
2. Click Select PSP Alpha 3 MAX and choose your PSP Alpha 3 MAX / Zero 3 Double Upper file. Any format, region or edition is accepted, including CHD and ISO. You can also drop it directly onto the PSP row.
3. Choose an output folder and create the BIN.

Output: SFA3U_C11.bin
Bytes: 188612608
SHA-256: 7194291cd16a4ae84e19879eb8d95e8e1b6a866a24d49a2c09bd8ef8b16222c3

Windows x64. No internet connection or external conversion tools required. Input files are preserved; existing output files are not overwritten.

C11 adds CROUCH CANCEL: ON/OFF to the in-game Operator Menu, default ON. Hold Start for three seconds to open it. Play continues while it is open. Shin Akuma and gray Final Bison selection links are retained.
